var style = require("./style.js");

module.exports = {
  HTML: function (tt) {
    // return `
    // <!doctype html>
    // <head>
    // <meta charset="UTF-8">
    // <title></title>
    // ${style.css()}
    // </head>
    // <body>
    // ${getfiles}
    // <div class=origin>
    //     <form action="myrouter/addpart" method="post">
    //     <input type="text" name="part">
    //     <input type="submit" value="파트추가">
    //     </form>
    // </div>
    // <div class=origin>
    //     ${db}
    // </div>
    // </body>
    // </html>
    // `;
    return `
    <!DOCTYPE html>
<html class="" lang="">
  <head>
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="generator" content="Silex v2.2.11" />
    <!-- End of generator meta tag -->
    <script
      type="text/javascript"
      src="https://editor.silex.me/static/2.11/jquery.js"
      data-silex-static=""
    ></script>
    <script
      type="text/javascript"
      src="https://editor.silex.me/static/2.11/jquery-ui.js"
      data-silex-static=""
      data-silex-remove-publish=""
    ></script>
    <script
      type="text/javascript"
      src="https://editor.silex.me/static/2.11/pageable.js"
      data-silex-static=""
      data-silex-remove-publish=""
    ></script>
    <script
      type="text/javascript"
      src="https://editor.silex.me/static/2.11/front-end.js"
      data-silex-static=""
    ></script>
    <link
      rel="stylesheet"
      href="https://editor.silex.me/static/2.11/normalize.css"
      data-silex-static=""
    />
    <link
      rel="stylesheet"
      href="https://editor.silex.me/static/2.11/front-end.css"
      data-silex-static=""
    />
   
    <style type="text/css" class="silex-style"></style>
    <script type="text/javascript" class="silex-script"></script>
    ${style.css()}
    <style class="silex-inline-styles" type="text/css">
      .body-initial {
        background-color: rgba(13, 13, 13, 1);
        position: static;
      }
      .silex-id-1478366444112-1 {
        background-color: rgba(13, 13, 13, 1);
        position: static;
        margin-top: -1px;
        border-color: rgba(173, 173, 173, 1);
      }
      .silex-id-1478366444112-0 {
        background-color: rgba(13, 13, 13, 1);
        min-height: 658px;
        position: relative;
        margin-left: auto;
        margin-right: auto;
        border-color: rgba(158, 158, 158, 1);
        display: block;
      }
      .silex-id-1474394621033-3 {
        position: static;
        margin-top: -1px;
        background-color: rgba(13, 13, 13, 1);
        border-color: rgba(164, 162, 162, 1);
        border-width: 0 0 2px 0;
        border-style: solid;
      }
      .silex-id-1474394621032-2 {
        background-color: rgba(13, 13, 13, 1);
        min-height: 298px;
        position: relative;
        margin-left: auto;
        margin-right: auto;
        border-color: rgba(71, 71, 71, 1);
      }
      .silex-id-1604381522345-1 {
        width: 135px;
        height: 125px;
        position: absolute;
        top: 50px;
        left: 60px;
      }
      .silex-id-1604381556411-2 {
        width: 170px;
        min-height: 80.3515625px;
        position: absolute;
        top: 180px;
        left: 45px;
        background-color: transparent;
      }
      .silex-id-1604643193909-2 {
        width: 270px;
        min-height: 1900px;
        background-color: rgba(38, 38, 39, 1);
        position: absolute;
        top: 1px;
        left: 0px;
        display: block;
      }
      .silex-id-1604643380215-3 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 295px;
        left: 0px;
        border-width: 2px 0 0 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1604644963736-10 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 0px;
        left: 80px;
      }
      .silex-id-1604710473649-0 {
        width: 26px;
        height: 31px;
        position: absolute;
        top: 10px;
        left: 35px;
      }
      .silex-id-1605152678603-4 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 300px;
        left: 0px;
        border-width: 2px 0 2px 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      /* .silex-id-1605153310902-18 {width: 110px; min-height: 53px; background-color: rgba(210,208,208,1); position: absolute; top: 103px; left: 13px;} */
      .silex-id-1605153603327-20 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(66, 66, 66, 1);
        position: absolute;
        top: 20px;
        left: 13px;
      }
      .silex-id-1605153782286-21 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 103px;
        left: 13px;
      }
      .silex-id-1605153789022-23 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 223px;
        left: 13px;
      }
      .silex-id-1605153856283-25 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 343px;
        left: 13px;
      }
      .silex-id-1605153856681-26 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 283px;
        left: 13px;
      }
      .silex-id-1605153983873-28 {
        width: 110px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 405px;
        left: 13px;
      }
      .silex-id-1605154601439-30 {
        width: 820px;
        min-height: 53px;
        background-color: rgba(66, 66, 66, 1);
        position: absolute;
        top: 20px;
        left: 137px;
      }
      .silex-id-1605156214985-32 {
        width: 195px;
        min-height: 45px;
        background-color: rgba(99, 99, 99, 1);
        position: absolute;
        top: 102.73661804199219px;
        left: 137.3267822265625px;
      }
      .silex-id-1605157281739-38 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1605158436114-42 {
        width: 135px;
        height: 125px;
        position: absolute;
        top: 50px;
        left: 60px;
      }
      .silex-id-1605158436114-43 {
        width: 170px;
        min-height: 70px;
        position: absolute;
        top: 180px;
        left: 45px;
        background-color: transparent;
      }
      .silex-id-1605158642745-48 {
        width: 26px;
        height: 31px;
        position: absolute;
        top: 10px;
        left: 35px;
      }
      .silex-id-1605169253679-1 {
        width: 869px;
        min-height: 53px;
        background-color: rgba(66, 66, 66, 1);
        position: absolute;
        top: 20px;
        left: 23px;
      }
      .silex-id-1605169308724-2 {
        width: 193px;
        min-height: 221px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 88.234375px;
        left: 23.125px;
      }
      .silex-id-1605169337585-3 {
        width: 132px;
        height: 133px;
        position: absolute;
        top: 113.84375px;
        left: 52.109375px;
      }
      .silex-id-1605169362105-5 {
        width: 100px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 88.79180908203125px;
        left: 394.00347900390625px;
      }
      .silex-id-1605169414376-6 {
        width: 100px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 88.92049407958984px;
        left: 506.0069580078125px;
      }
      .silex-id-1605169429086-8 {
        width: 100px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 88.68417358398438px;
        left: 618.0103759765625px;
      }
      .silex-id-1605169447034-10 {
        width: 70.86804962158203px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 88px;
        left: 821.131950378418px;
      }
      .silex-id-1605169479817-12 {
        width: 70px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 418.9965515136719px;
        left: 820.8231201171875px;
      }
      .silex-id-1605169671992-14 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 295px;
        left: 0px;
        border-width: 2px 0 0 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1605169671992-15 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1605169671992-16 {
        width: 26px;
        height: 31px;
        position: absolute;
        top: 10px;
        left: 35px;
      }
      .silex-id-1605169710227-20 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 432px;
        left: 0px;
        border-width: 2px 0 2px 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1605169710227-22 {
        width: 64px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1605169710227-23 {
        width: 135px;
        height: 125px;
        position: absolute;
        top: 50px;
        left: 60px;
      }
      .silex-id-1605169710227-24 {
        width: 170px;
        min-height: 70px;
        position: absolute;
        top: 180px;
        left: 45px;
        background-color: transparent;
      }
      .silex-id-1605169710227-25 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 295px;
        left: 0px;
        border-width: 2px 0 0 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1605169710227-26 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 0px;
        left: 80px;
      }
      .silex-id-1605169710227-27 {
        width: 26px;
        height: 31px;
        position: absolute;
        top: 10px;
        left: 35px;
      }
      .silex-id-1605173129472-2 {
        width: 342px;
        min-height: 125px;
        position: absolute;
        top: 22.0069580078125px;
        left: 374.9930419921875px;
      }
      .silex-id-1606317110046-0 {
        width: 135px;
        height: 125px;
        position: absolute;
        top: 50px;
        left: 60px;
      }
      .silex-id-1606317159983-2 {
        width: 170px;
        min-height: 80px;
        position: absolute;
        top: 180px;
        left: 45px;
        background-color: transparent;
      }
      .silex-id-1606317196527-4 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 295px;
        left: 0px;
        border-width: 2px 0 0 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1606317196527-5 {
        width: 116px;
        min-height: 53.2421875px;
        position: absolute;
        top: 0px;
        left: 80px;
      }
      .silex-id-1606317196527-6 {
        width: 26px;
        height: 31px;
        position: absolute;
        top: 10px;
        left: 35px;
      }
      .silex-id-1606318077720-19 {
        width: 689px;
        min-height: 53px;
        background-color: rgba(66, 66, 66, 1);
        position: absolute;
        top: 24px;
        left: 213px;
      }
      .silex-id-1606318304197-25 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 102px;
        left: 49px;
      }
      .silex-id-1606318503383-27 {
        width: 100px;
        min-height: 53px;
        background-color: rgba(173, 173, 173, 1);
        position: absolute;
        top: 24px;
        left: 49.59375px;
      }
      .silex-id-1606318527883-29 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 177px;
        left: 49.8125px;
      }
      .silex-id-1606318528783-30 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 251px;
        left: 49.8125px;
      }
      .silex-id-1606318644502-34 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 102px;
        left: 212.84375px;
      }
      .silex-id-1605156214985-34 {
        width: 195px;
        min-height: 45px;
        background-color: rgba(99, 99, 99, 1);
        position: absolute;
        top: 102.73661804199219px;
        left: 537.3267822265625px;
      }
      .silex-id-1605156214985-33 {
        width: 195px;
        min-height: 45px;
        background-color: rgba(99, 99, 99, 1);
        position: absolute;
        top: 102.73661804199219px;
        left: 337.3267822265625px;
      }
      .silex-id-1606318669855-36 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 102px;
        left: 377px;
      }
      .silex-id-1606318760018-38 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 177px;
        left: 212px;
      }
      .silex-id-1606318797559-41 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 324px;
        left: 49.9375px;
      }
      .silex-id-1606318806516-43 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 397px;
        left: 50.21875px;
      }
      .silex-id-1606318829433-45 {
        width: 99px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 470px;
        left: 49.9375px;
      }
      .silex-id-1606318837842-47 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 251px;
        left: 212.0625px;
      }
      .silex-id-1606318838237-48 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 324px;
        left: 212.5625px;
      }
      .silex-id-1606318842526-49 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 397px;
        left: 212.90625px;
      }
      .silex-id-1606318846397-50 {
        width: 126px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 470px;
        left: 213px;
      }
      .silex-id-1606318868384-56 {
        width: 400px;
        min-height: 53px;
        background-color: rgba(210, 208, 208, 1);
        position: absolute;
        top: 771px;
        left: 647.5625px;
      }
      .silex-id-1606318943550-58 {
        width: 135px;
        height: 125px;
        position: absolute;
        top: 50px;
        left: 60px;
      }
      .silex-id-1606321378453-0 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 177px;
        left: 377.5px;
      }
      .silex-id-1606321411377-2 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 252px;
        left: 377.75px;
      }
      .silex-id-1606321411800-3 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 327px;
        left: 377.59375px;
      }
      .silex-id-1606321414784-4 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 402px;
        left: 377.6875px;
      }
      .silex-id-1606321419027-5 {
        width: 521px;
        min-height: 75px;
        background-color: transparent;
        position: absolute;
        top: 477px;
        left: 377.34375px;
      }
      .silex-id-1606365278943-5 {
        width: 400px;
        min-height: 100px;
        background-color: transparent;
        position: absolute;
        top: 243px;
        left: 493px;
      }
      .silex-id-1606365461296-11 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 336px;
        left: 90px;
      }
      .silex-id-1606365466562-13 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 372px;
        left: 90px;
      }
      .silex-id-1606365466562-33 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 408px;
        left: 90px;
      }
      .silex-id-1606365725687-15 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 432px;
        left: 00px;
        border-width: 2px 0 2px 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1606365725687-17 {
        width: 64px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1606365725687-18 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 336px;
        left: 90px;
      }
      .silex-id-1606365725687-19 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 372px;
        left: 90px;
      }
      .silex-id-1606365725687-32 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 408px;
        left: 90px;
      }
      .silex-id-1606365729886-20 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 432px;
        left: -0.03125px;
        border-width: 2px 0 2px 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1606365729886-22 {
        width: 64px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1606365729886-23 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 336px;
        left: 90px;
      }
      .silex-id-1606365729886-24 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 372px;
        left: 90px;
      }
      .silex-id-1606365729886-31 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 408px;
        left: 90px;
      }
      .silex-id-1606365817473-25 {
        width: 265px;
        min-height: 55px;
        background-color: transparent;
        position: absolute;
        top: 432px;
        left: -0.03125px;
        border-width: 2px 0 2px 0;
        border-style: solid;
        border-color: rgba(255, 255, 255, 1);
      }
      .silex-id-1606365817473-27 {
        width: 64px;
        min-height: 53px;
        position: absolute;
        left: 80px;
      }
      .silex-id-1606365817473-28 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 336px;
        left: 90px;
      }
      .silex-id-1606365817473-29 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 372px;
        left: 90px;
      }
      .silex-id-1606365817473-30 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 408px;
        left: 90px;
      }
      .silex-id-12345 {
        width: 116px;
        min-height: 53px;
        position: absolute;
        top: 400px;
        left: 90px;
      }
      .silex-id-1606368631609-2 {
        width: 25px;
        height: 25px;
        position: absolute;
        top: 15px;
        left: 35px;
      }
      .silex-id-1606368660810-3 {
        width: 25px;
        height: 25px;
        position: absolute;
        top: 15px;
        left: 35px;
      }
      .silex-id-1606368666667-4 {
        width: 25px;
        height: 25px;
        position: absolute;
        top: 15px;
        left: 35px;
      }
      .silex-id-1606368704888-5 {
        width: 25px;
        height: 25px;
        position: absolute;
        top: 15px;
        left: 35px;
      }
      @media only screen and (max-width: 480px) {
      }
    </style>

    <link
      href="https://fonts.googleapis.com/css?family=Roboto"
      rel="stylesheet"
      class="silex-custom-font"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style type="text/css" class="silex-style-settings">
      .website-width {
        width: 1015px;
      }
      @media (min-width: 481px) {
        .silex-editor {
          min-width: 1215px;
        }
      }
    </style>
    <style
      class="silex-prodotype-style"
      type="text/css"
      data-style-id="all-style"
    >
      .text-element > .silex-element-content {
        font-family: "Roboto", sans-serif;
        font-style: normal;
        color: #ffffff;
        text-align: justify;
        border-color: #ffffff;
        -webkit-transition: all 1s ease;
        -moz-transition: all 1s ease;
        -o-transition: all 1s ease;
        transition: all 1s ease;
      }
      a {
        color: #ffffff;
        text-decoration: none;
      }
      [data-silex-href] {
        color: #ffffff;
        text-decoration: none;
      }
    </style>
    <style
      class="silex-prodotype-style"
      type="text/css"
      data-style-id="style-all-style1"
    >
      .style-all-style1.text-element > .silex-element-content {
        font-family: "Roboto", sans-serif;
        color: #ffffff;
        -webkit-transition: all 1s ease;
        -moz-transition: all 1s ease;
        -o-transition: all 1s ease;
        transition: all 1s ease;
      }
    </style>
  </head>
  <body
    data-silex-id="body-initial"
    class="body-initial all-style enable-mobile prevent-resizable prevent-selectable editable-style silex-runtime"
    data-silex-type="container-element"
    style=""
    data-new-gr-c-s-loaded="14.984.0"
  >
    <div
      data-silex-type="container-element"
      class="container-element editable-style silex-id-1474394621033-3 section-element prevent-resizable hide-on-mobile"
      data-silex-id="silex-id-1474394621033-3"
      style=""
    >
      <div
        data-silex-type="container-element"
        class="editable-style silex-element-content silex-id-1474394621032-2 container-element website-width selected"
        data-silex-id="silex-id-1474394621032-2"
        style=""
      ></div>

      <!-- 왼쪽 항목 -->
      <div
        data-silex-type="container-element"
        class="editable-style container-element silex-id-1604643193909-2 hide-on-mobile"
        data-silex-id="silex-id-1604643193909-2"
        style=""
      >
        <div
          data-silex-type="image-element"
          class="editable-style image-element silex-id-1605169710227-23 page-main paged-element style-all-style1"
          data-silex-id="silex-id-1605169710227-23"
          style=""
          data-silex-href="#!page-main"
        >
          <img src="logo.637cfd18.jpg" />
        </div>

        <div
          data-silex-type="text-element"
          class="editable-style text-element silex-id-1605169710227-24 page-main paged-element style-all-style1"
          data-silex-id="silex-id-1605169710227-24"
          style=""
        >
          <div class="silex-element-content normal">
            <h1>
              <b
                ><a href="/home" linktype="LinkTypePage" class=""
                  >PLASS DGU</a
                ></b
              ><br />
            </h1>
            <span
              class="_wysihtml-temp-caret-fix"
              style="
                position: absolute;
                display: block;
                min-width: 1px;
                z-index: 99999;
              "
              >﻿</span
            >
          </div>
        </div>

        <div
          data-silex-type="container-element"
          class="editable-style container-element silex-id-1605169710227-25 page-main paged-element"
          data-silex-id="silex-id-1605169710227-25"
          style=""
        >
          <div
            data-silex-type="text-element"
            class="editable-style text-element silex-id-1605169710227-26 page-main paged-element"
            data-silex-id="silex-id-1605169710227-26"
            style=""
          >
            <div class="silex-element-content normal">
              <p>
                <b
                  ><a
                    href="/teamPage"
                    title="공동문서 작업"
                    linktype="LinkTypePage"
                    class=""
                    >공동 문서 작업</a
                  ></b
                >
              </p>
              <span
                class="_wysihtml-temp-caret-fix"
                style="
                  position: absolute;
                  display: block;
                  min-width: 1px;
                  z-index: 99999;
                "
                >﻿</span
              >
            </div>
          </div>
          <div
            data-silex-type="image-element"
            class="editable-style image-element silex-id-1605169710227-27 page-main paged-element"
            data-silex-id="silex-id-1605169710227-27"
            style=""
          >
            <img src="group%20icon.png" />
          </div>
        </div>

        <div
          data-silex-type="text-element"
          class="editable-style text-element silex-id-1606365461296-11 page-main paged-element"
          data-silex-id="silex-id-1606365461296-11"
          style=""
        >
          <div class="silex-element-content normal">
            <p>
              <b
                >-
                <a href="/teamPage" linktype="LinkTypePage" class=""
                  >Group 정보</a
                ></b
              >
            </p>
          </div>
        </div>

        <div
          data-silex-type="text-element"
          class="editable-style text-element silex-id-1606365466562-13 page-main paged-element"
          data-silex-id="silex-id-1606365466562-13"
          style=""
        >
          <div class="silex-element-content normal">
            <p>
              <b
                >-&nbsp;<a
                  href="/workList"
                  title="공동문서 작업"
                  linktype="LinkTypePage"
                  class="page-link-active"
                  >작업 List</a
                >
              </b>
            </p>
          </div>
        </div>

        <div
          data-silex-type="text-element"
          class="editable-style text-element silex-id-12345 page-main paged-element"
          data-silex-id="silex-id-12345"
          style=""
        >
          <div class="silex-element-content normal">
            <p>
              <b
                >-
                <a href="/dms" linktype="LinkTypePage" class=""
                  >파일업로드</a
                ></b
              >
            </p>
          </div>
        </div>

        <div
          data-silex-type="container-element"
          class="editable-style container-element silex-id-1605169710227-20 page-main paged-element"
          data-silex-id="silex-id-1605169710227-20"
          style=""
        >
          <div
            data-silex-type="text-element"
            class="editable-style text-element silex-id-1605169710227-22 page-main paged-element"
            data-silex-id="silex-id-1605169710227-22"
            style=""
          >
            <div class="silex-element-content normal">
              <p>
                <b><a href="/profilePage" class="">프로필</a></b>
              </p>
            </div>
          </div>
          <div
            data-silex-type="image-element"
            class="editable-style image-element silex-id-1606368660810-3 page-main paged-element"
            data-silex-id="silex-id-1606368660810-3"
            style=""
          >
            <img src="icon-profile-user.png" />
          </div>
        </div>
      </div>
    </div>

    <!-- 가운데 몸체 -->
    <div
      data-silex-type="container-element"
      class="editable-style section-element silex-id-1478366444112-1"
      data-silex-id="silex-id-1478366444112-1"
      title=""
      style=""
    >
      <div
        data-silex-type="container-element"
        class="editable-style container-element silex-id-1478366444112-0 website-width"
        data-silex-id="silex-id-1478366444112-0"
        title=""
        style=""
      >
      <div>
 ${tt}
</div>
        <div
          data-silex-type="text-element"
          class="editable-style text-element silex-id-1605173129472-2 page-main paged-element"
          data-silex-id="silex-id-1605173129472-2"
        >
          <div class="silex-element-content normal">
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

    `;
  },
};
