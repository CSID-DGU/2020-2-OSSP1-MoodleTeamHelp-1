var http = require('http');
var fs = require('fs');
var express = require('express');
var app = express();
var Inko = require('inko');
var inko = new Inko();
const bodyParser = require('body-parser');

var myRouter = require('./myrouter.js');
var template = require('./template.js');
var j = 0;

const mysql      = require('mysql');
const dbconfig   = require('./config/database.js');
const connection = mysql.createConnection(dbconfig);

app.use(bodyParser.urlencoded({extended:false}));
app.set('port', process.env.PORT || 8888);

app.use(express.static('public'));
app.use('/grouprepository', express.static('grouprepository'));

app.use('/myrouter',myRouter);

var IdRepository=[];

app.get('/', function (req, res){
    var loginId=req.query.id;
    IdRepository=[];
    
    for(var j in db){
        if(db[j].guid==loginId){
            if(db[j].g_path){
                IdRepository.push(db[j].g_path);
            }  
            else{
                var newrpos='./grouprepository/'+db[j].c_name+'_'+db[j].gid;
                fs.mkdir(newrpos,err=>{
                    connection.query(
                        `Update mdl_groups set group_path = "${db[j].c_name+'_'+db[j].gid}"
                        where id=${db[j].gid};`,
                    );
                    dbqueryinput();
                })
            }
        }
    }

   function getFiles(dir, files_){
       files_= files_ || [];
       var files = fs.readdirSync(dir);
       files_.push('<ul>'); 
       for (var i in files){
           if(IdRepository.indexOf(files[i])===-1) continue;
           else
           files_.push(`<li><a href="/${files[i]}?id=${loginId}">${files[i]}</a></li>`);
       }
       files_.push('</ul>')
       files_=files_.join('');
       return files_;
   }


   var tt=getFiles('./grouprepository',0);
   var html=`
   <!doctype html> 
    <head>
    
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title></title>
    </head>
    <body>
    ${tt}
    </body>
    </html>
   `
   res.writeHead(200);
   res.end(html);
});

app.get('/:id', function (req, res) {
    var loginId=req.query.id;
    var group=req.params.id;
    group = './grouprepository/'+group;
    function getFiles2(dir, files_){
        files_= files_ || [];
        var files = fs.readdirSync(dir);
        files_.push('<ul>'); 
        for (var i in files){
            if(IdRepository.indexOf(files[i])===-1) continue;
            else
            files_.push(`<li><a href="/${files[i]}?id=${loginId}">${files[i]}</a></li>`);
        }
        files_.push('</ul>')
        files_=files_.join('');
        return files_;
    }
 
    function getFiles(dir, isPart, files_) {
        files_ = files_ || [];
        var files = fs.readdirSync(dir).map(filename=>{
            return{
                filename: filename,
                mtime: fs.statSync(dir+'/'+filename).mtime
            }
        })

        if(isPart==1)
            files.sort((a,b)=>a.mtime-b.mtime);
        var idx=0;
        for (var i in files) {
            var name = dir + '/' + files[i].filename;
            var forbid = "_content";
            if(name.indexOf(forbid)!=-1){
                continue;
            }
            j = j+1;
            if (fs.statSync(name).isDirectory()) {
                let uname = name.replace(/\//g, ',');
                files_.push('<ul>')
                files_.push(`<div class="part"> 
                <div class="parttitle">
                <form action="myrouter/deletepart/${uname}?id=${loginId}" method="post">
                <h2 class="titlefont" style=color:white;>
                <input type="image" src="white.png" style="width:20px; height:auto; margin-left:5%;"alt="x">
                    ${files[i].filename}
                </h2>
                </form>
                </div>
                `);
                files_.push(`
                <div class="partupload">
                <form action="myrouter/fileupload/${uname}?id=${loginId}" method="post"  enctype="multipart/form-data">
                <input type="file" name="filetoupload"  style="width:100%; font-size:30%; color:white">
                <input type="submit" style="font-size:30%;">
                </form>
                </div>
                `)
                
                getFiles(name, 1, files_);

               
                files_.push('</div>');
                if(i<files.length-1)
                {
                    files_.push(`
                    <div class="link">
                    <hr style="color:white; height:8px; border:none; background-color:white"  align="center">
                    </div>
                    `)
                }
                files_.push('</ul>')

            } else {
                var spliturl = name.split("/");
                var fname = spliturl[spliturl.length - 1];
                let uname = name.replace(/\//g, ',');

                var path = uname;
                var fpath = path.replace(/,/g, '/');
                var splitname = fpath.split(".");
                var ext = "." + splitname[splitname.length - 1];
                var ffpath = fpath.replace(ext ,'_content.txt');
                var fbpath = inko.ko2en(ffpath);
                var finalpath = fbpath.replace('./grouprepository','/grouprepository');
                files_.push(`
                <div class="vertical2">
                </div>`);

                
                files_.push(`
                    <div id = "listcontent${j}" class="listcontent" style="border:2px solid white; overflow: auto; height: 100px; background-color:black; position:relative;">
                    `);
                files_.push(`
                <form action="myrouter/delete/${uname}?id=${loginId}" method="post" onsubmit="return confirm('정말 삭제하시겠습니까?');">
                <div class="left">
                <input type="image" src="white.png" style="width:15px; height:auto; margin-left:5%;"alt="x">
                </div>
                </form>
                <a class="listfont" href="myrouter/download/${uname}?id=${loginId}"><b>&nbsp;&nbsp;${fname}</b></a>
                <br>
                <form class = "detail" action="myrouter/edit/${uname}">
                <input type = "button" class = "detailBT" value = "detail" id = "dis${j}"><br>
                <textarea name = "content" cols="35" rows="9" id = 'comment_area${j}' style="display:none" ></textarea><br>
                <input type="submit" value="Edit" id = 'comment_edit${j}' style="display:none" >
                </form>

                </div>
                <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
                <script type="text/javascript">
                    $(document).on("click","#dis${j}", function(){
                        if($("#comment_area${j}").css('display') == 'none'){
                            $("#comment_area${j}").show();
                            $("#comment_edit${j}").show();
                            $("#listcontent${j}").css('width','200px');
                            $("#listcontent${j}").css('height','200px');
                            $("#listcontent${j}").css('z-index', '1000');
                            $("#comment_area${j}").load("${finalpath}",function(txt, status,xhr){
                                if (status == "success") {
                                } else if (status == "error") {
                                    alert("로딩 실패");
                                    alert('${finalpath}');
                                    alert("Error: " + xhr.status + ": " + xhr.statusText);
                                }
                            });
                            }else{
                                $("#listcontent${j}").css('width','125px');
                                $("#listcontent${j}").css('height','100px');
                                $("#listcontent${j}").css('z-index', 'initial');
                                $("#comment_area${j}").hide();
                                $("#comment_edit${j}").hide();
                            }
                    });

                 </script>
                `)
            }
            idx++;
        }
        
        files_ = files_.join('');
        return files_;
    }

    let ugroup = group.replace(/\//g, ',');
    var html = template.HTML(getFiles(group,0), getFiles2('./grouprepository',0), ugroup+'?id='+loginId);
    res.writeHead(200);
    res.end(html);
});

var db=[];

var server = http.createServer(app).listen(app.get('port'), function () {
    dbqueryinput()
});

function dbqueryinput(){
    connection.query(
        `SELECT gm.id, gm.groupid, gm.userid, g.group_path, c.fullname
        from mdl_groups_members gm
        left outer join mdl_groups g on gm.groupid=g.id
        left outer join mdl_course c on g.courseid=c.id`, (error, rows) => {
            db=[];
            if (error) throw error;
            for (var i in rows) {
                db.push(
                    {
                        'gm' : rows[i].id,
                        'gid' : rows[i].groupid,
                        'guid' : rows[i].userid,
                        'g_path' : rows[i].group_path,
                        'c_name' : rows[i].fullname

                    }
                );
            }
        }
    );
}


